WGW DUAL IPHONE TEST APPS

This package contains two separate installable web apps:
1. FOGO - green leaf icon
2. Recycle - yellow leaf icon

To appear as two separate one-touch icons on an iPhone, the two folders must be hosted at two different HTTPS addresses, for example:
https://your-site.example/fogo/
https://your-site.example/recycle/

IPHONE INSTALLATION
1. Open the FOGO address in Safari.
2. Tap Share.
3. Tap Add to Home Screen.
4. Confirm the name FOGO.
5. Repeat with the Recycle address.

The apps save data on the individual phone.
At the end of the shift, tap Export Today's Report or Share Summary.
The CSV can be sent to Shane or Toby using Mail, Messages, AirDrop, or another iPhone share option.

IMPORTANT
Opening index.html directly from the ZIP is enough to inspect the screen on a computer, but proper iPhone installation, GPS permissions, offline caching, and the two separate icons require HTTPS hosting.
